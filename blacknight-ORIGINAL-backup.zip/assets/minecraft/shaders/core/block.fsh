#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec2 texCoord0;

out vec4 fragColor;

float nightVisibility(vec3 light) {
    // The vanilla lightmap combines sky light and block light.
    // An extreme threshold suppresses almost all ambient night light.
    // Only very bright block light should remain visible.
    float level = max(max(light.r, light.g), light.b);
    return smoothstep(0.90, 0.98, level);
}


// Warm amber tint for block light (torches, lanterns, campfires, etc.).
// Sky light is close to neutral and therefore receives little or no tint.
float amberTorchFactor(vec3 light) {
    float brightness = max(max(light.r, light.g), light.b);
    float redDominance = max(light.r - light.b, 0.0);
    return smoothstep(0.025, 0.18, redDominance) * smoothstep(0.12, 0.62, brightness);
}

vec3 applyAmberTorch(vec3 color, vec3 light) {
    float warmth = amberTorchFactor(light) * 0.72;
    vec3 amber = vec3(1.0, 0.72, 0.43);
    return color * mix(vec3(1.0), amber, warmth);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    color.rgb *= nightVisibility(lightMapColor.rgb);
    color.rgb = applyAmberTorch(color.rgb, lightMapColor.rgb);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) discard;
#endif
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
