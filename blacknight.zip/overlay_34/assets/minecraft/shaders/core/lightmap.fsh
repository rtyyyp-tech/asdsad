#version 150

// ---- TUNING ----------------------------------------------------------------
// Raw light level at which the wall ends (0..1, 1 level = 1/15).
// 0.1334 == level 2. Lower = tighter radius.
#define WALL_LEVEL      0.1334
// Edge sharpness of the wall. Higher = harder transition.
#define WALL_SHARPNESS  60.0
// Raw SKY light influence: 0.0 = daytime is dark too (only torches/lava shine),
// 0.15 = sky light pushes the wall back a bit.
#define SKY_INFLUENCE   0.0
// ----------------------------------------------------------------------------

uniform float AmbientLightFactor;
uniform float SkyFactor;
uniform float BlockFactor;
uniform int UseBrightLightmap;
uniform vec3 SkyLightColor;
uniform float NightVisionFactor;
uniform float DarknessScale;
uniform float DarkenWorldFactor;
uniform float BrightnessFactor;

in vec2 texCoord;

out vec4 fragColor;

float get_brightness(float level) {
    float curved_level = level / (4.0 - 3.0 * level);
    return mix(curved_level, 1.0, AmbientLightFactor);
}

vec3 notGamma(vec3 x) {
    vec3 nx = 1.0 - x;
    return 1.0 - nx * nx * nx * nx;
}

void main() {
    float block_level = floor(texCoord.x * 16.0) / 15.0;
    float sky_level = floor(texCoord.y * 16.0) / 15.0;

    float block_brightness = mix(get_brightness(block_level), 1.0, 0.0) * BlockFactor;
    float sky_brightness = mix(get_brightness(sky_level), 1.0, 0.0) * SkyFactor;

    vec3 color = vec3(
        block_brightness,
        block_brightness * ((block_brightness * 0.6 + 0.4) * 0.6 + 0.4),
        block_brightness * (block_brightness * block_brightness * 0.6 + 0.4)
    );

    if (UseBrightLightmap != 0) {
        color = mix(color, vec3(0.99, 1.12, 1.0), 0.25);
        color = clamp(color, 0.0, 1.0);
    } else {
        color += SkyLightColor * sky_brightness;
        color = mix(color, vec3(0.75), 0.04);

        vec3 darkened_color = color * vec3(0.7, 0.6, 0.6);
        color = mix(color, darkened_color, DarkenWorldFactor);
    }

    if (NightVisionFactor > 0.0) {
        float max_component = max(color.r, max(color.g, color.b));
        if (max_component > 0.0001 && max_component < 1.0) {
            vec3 bright_color = color / max_component;
            color = mix(color, bright_color, NightVisionFactor);
        }
    }

    if (UseBrightLightmap == 0) {
        color = clamp(color - vec3(DarknessScale), 0.0, 1.0);
    }

    vec3 ng = notGamma(color);
    color = mix(color, ng, BrightnessFactor);
    color = mix(color, vec3(0.75), 0.04);
    color = clamp(color, 0.0, 1.0);

    float raw_light = max(block_level, sky_level * SKY_INFLUENCE);
    float wall = 1.0 - clamp((WALL_LEVEL - raw_light) * WALL_SHARPNESS, 0.0, 1.0);
    color = mix(vec3(0.0), color, wall);

    fragColor = vec4(color, 1.0);
}
