#version 330

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} lightmapInfo;

// ---- TUNING ----------------------------------------------------------------
// Raw light level (0..1, 1 level = 1/15) at which the wall ends.
// 0.1334 == level 2. Lower = tighter radius.
#define WALL_LEVEL      0.1334
// Edge sharpness of the wall. Higher = harder transition.
#define WALL_SHARPNESS  60.0
// Raw SKY light influence: 0.0 = daytime is dark too (only torches/lava shine),
// 0.15 = sky light pushes the wall back a bit.
#define SKY_INFLUENCE   0.0
// ----------------------------------------------------------------------------

in vec2 texCoord;

out vec4 fragColor;

float get_brightness(float level) {
    return level / (4.0 - 3.0 * level);
}

vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    if (maxComponent <= 0.0001) {
        return color;
    }
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

float parabolicMixFactor(float level) {
    return (2.0 * level - 1.0) * (2.0 * level - 1.0);
}

void main() {
    float block_level = floor(texCoord.x * 16.0) / 15.0;
    float sky_level = floor(texCoord.y * 16.0) / 15.0;

    float block_brightness = get_brightness(block_level) * lightmapInfo.BlockFactor;
    float sky_brightness = get_brightness(sky_level) * lightmapInfo.SkyFactor;

    vec3 nightVisionColor = lightmapInfo.NightVisionColor * lightmapInfo.NightVisionFactor;
    vec3 color = max(lightmapInfo.AmbientColor, nightVisionColor);

    color += lightmapInfo.SkyLightColor * sky_brightness;

    vec3 BlockLightColor = mix(lightmapInfo.BlockLightTint, vec3(1.0), 0.9 * parabolicMixFactor(block_level));
    color += BlockLightColor * block_brightness;

    color = mix(color, color * vec3(0.7, 0.6, 0.6), lightmapInfo.BossOverlayWorldDarkeningFactor);

    color = color - vec3(lightmapInfo.DarknessScale);

    color = clamp(color, 0.0, 1.0);
    vec3 ng = notGamma(color);
    color = mix(color, ng, lightmapInfo.BrightnessFactor);

    float raw_light = max(block_level, sky_level * SKY_INFLUENCE);
    float wall = 1.0 - clamp((WALL_LEVEL - raw_light) * WALL_SHARPNESS, 0.0, 1.0);
    color = mix(vec3(0.0), color, wall);

    fragColor = vec4(color, 1.0);
}
